create function interval_pl_timetz(interval, time with time zone) returns time with time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$select $2 + $1$$;

comment on function interval_pl_timetz(interval, time with time zone) is 'implementation of + operator';

alter function interval_pl_timetz(interval, time with time zone) owner to admin;

